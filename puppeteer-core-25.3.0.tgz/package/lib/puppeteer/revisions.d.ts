/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @internal
 */
export declare const PUPPETEER_REVISIONS: Readonly<{
    chrome: "150.0.7871.24";
    'chrome-headless-shell': "150.0.7871.24";
    firefox: "stable_152.0.4";
}>;
//# sourceMappingURL=revisions.d.ts.map