/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
export declare const packageVersion = "25.3.0";
//# sourceMappingURL=version.d.ts.map